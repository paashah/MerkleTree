TEAM MEMBERS:
Jacob Smith (burgerman1020@tamu.edu)
Paanery Shah (pshah@tamu.edu)


YOUTUBE URL: https://youtu.be/ZKFEyGE4WlA


HOW TO RUN:
Add all files to an eclipse Java Project and run the driver under the package name "MainPackage". 
Output should be a user interface that provides instructions on what to input and what to expect 
as output. Inputs should only ever be files or array based merkle trees and will either create a 
merkle tree or determine if two files/merkle trees are equivalent.